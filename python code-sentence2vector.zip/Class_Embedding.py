from sentence_transformers import SentenceTransformer, LoggingHandler
import numpy as np
import logging
import sys


def embedding(name):
        Kset = set()
        mc_K = []
        # for name in k_name:
        # D:/code/radon20221007/data/merged-3/new_test_sentence/sentence_done/
        # D:/code/radon20221007/data/score/AllSentenceList/

        with open("src/edu/njupt/radon/utils/data/data/testInfo/ontoInfo/" + name) as f:
            K_axioms = f.read().split("\n")
            mc_K.append(K_axioms)
            for axiom in K_axioms:
                Kset.add(axiom)
            f.close()
        K = list(Kset)
        #print("data loaded!")
        sent_index = {}
        index_sent = {}
        index = 0
        for sentence in K:
            sent_index[sentence] = index
            index_sent[index] = sentence
            index += 1
        model = SentenceTransformer('paraphrase-albert-small-v2')
        sentence_embeddings = model.encode(K)
        return sentence_embeddings

