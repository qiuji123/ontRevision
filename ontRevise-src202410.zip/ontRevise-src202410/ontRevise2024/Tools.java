package edu.njupt.radon.exp.ontRevise2024;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import ilog.concert.IloException;
import ilog.concert.IloLPMatrix;
import ilog.cplex.IloCplex;

public class Tools {
	
	public static void main(String[] args)  throws Exception {		
		
		String o1Name = "km1500-4";
		String o2Name = "km1500-5";
		String resPath = "data/incOnt/"+o1Name+"-"+o2Name+".owl";
		mergeOnto(o1Name, o2Name, resPath);
	}
	

	public static String getOntoName(String str) {
		String name = "";
		if(str.equals("ALOD2Vec-cmt-ekaw")) {
			name = "OM0";
		} else if(str.equals("ALOD2Vec-conference-ekaw")) {
			name = "OM1";
		} else if(str.equals("GMap-conference-edas")) {
			name = "OM2";
		} else if(str.equals("GMap-edas-ekaw")) {
			name = "OM3";
		} else if(str.equals("Lily-cmt-conference")) {
			name = "OM4";
		} else if(str.equals("Lily-edas-ekaw")) {
			name = "OM5";
		} else if(str.equals("OTMapOnto-cmt-conference")) {
			name = "OM6";
		} else if(str.equals("OTMapOnto-conference-edas")) {
			name = "OM7";
		} else if(str.equals("OTMapOnto-ekaw-sigkdd")) {
			name = "OM8";
		} else if(str.equals("TOM-iasted-sigkdd")) {
			name = "OM9";
		} else if(str.equals("km1500-1000-1-km1500-1000-2")) {
			name = "KM0";
		} else if(str.equals("km1500-1000-2-km1500-1000-3")) {
			name = "KM1";
		} else if(str.equals("km1500-1000-3-km1500-1000-4")) {
			name = "KM2";
		} else if(str.equals("km1500-1000-4-km1500-1000-5")) {
			name = "KM3";
		} else if(str.equals("km1500-1000-5-km1500-1000-6")) {
			name = "KM4";
		} else if(str.equals("km1500-1000-6-km1500-1000-7")) {
			name = "KM5";
		} else if(str.equals("km1500-1000-7-km1500-1000-8")) {
			name = "KM6";
		} else if(str.equals("km1500-1000-8-km1500-1000-9")) {
			name = "KM7";
		} else if(str.equals("km1500-1000-9-km1500-1000-10")) {
			name = "KM8";
		} else {
			name = str;
		}
		return name;
	}
	
	public static String getStrategyName(String str) {
		String strategy = "";
		if(str.equals("base")) {
			strategy = "ex-base";
		} else if(str.equals("sig")) {
			strategy = "ex-sig";
		} else if(str.equals("score")) {
			strategy = "ex-score";
		} else if(str.equals("shapley")) {
			strategy = "ex-shapley";
		} else {
			strategy = str;
		}
		return strategy;
	}
	
	
	public static HashMap<String, HashSet<HashSet<String>>> readUcMUPS(String resPath)  throws Exception{			
		String line, ucName = null, axStr = null;
		boolean expBegin = false;
		HashSet<String> oneMUPS= new HashSet<String>();
		HashSet<HashSet<String>> allMUPS= new HashSet<HashSet<String>>();
		HashMap<String, HashSet<HashSet<String>>> ucMUPS = new HashMap<String, HashSet<HashSet<String>>>();
		
		/*String logPath = "results/conf2021/log.txt"; 
		System.setOut((new PrintStreamObject(logPath)).ps);		*/
		
		BufferedReader reader = new BufferedReader(new FileReader(resPath));		
		while ((line=reader.readLine())!=null) {
			if(line.startsWith("uc <")){ // uc <0> <http://conference#Contribution_co-author>				
				ucName = line.substring(line.indexOf("<http")+1, line.lastIndexOf(">"));
				allMUPS.clear();
			}else if(line.startsWith("Explanation <")) {
				expBegin = true;
			}else if(line.startsWith("  [")) {// [1] EquivalentObjectProperties(<http://cmt#hasAuthor> <http://conference#has_authors> )
				axStr = line.substring(line.indexOf("]")+2);
				oneMUPS.add(axStr);				
			}else if(expBegin && line.length()==0) {
				expBegin = false;
				allMUPS.add(new HashSet<String>(oneMUPS));				
				oneMUPS.clear();
				ucMUPS.put(ucName, new HashSet<HashSet<String>>(allMUPS));
			}
			
		}
		
		// check
		/*int ucNum = 0;
		for(String name : ucMUPS.keySet()) {
			System.out.println("uc <"+(ucNum++)+"> "+name);
			int mupsNum = 1;
			for(HashSet<String> oneMups : ucMUPS.get(name)) {
				System.out.println("Explanation <"+(mupsNum++)+">");
				int axNum = 1;
				for(String str : oneMups) {
					System.out.println(" ["+(axNum++)+"] "+str);
				}
			}
		}*/
		return ucMUPS;
	}

	public static HashSet<HashSet<OWLAxiom>> transferStrToMUPS(
			OWLOntology sourceOnto, HashMap<String, HashSet<HashSet<String>>> ucMUPSStr) {
		
		HashMap<String, OWLAxiom> strAxiomMap = new HashMap<String, OWLAxiom>();
		HashMap<String, OWLClass> strClassMap = new HashMap<String, OWLClass>();
		//HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> ucMUPS = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		
		for(OWLAxiom ax : sourceOnto.getLogicalAxioms()) {
			strAxiomMap.put(ax.toString(), ax);
		}
		for(OWLClass oc : sourceOnto.getClassesInSignature()) {
			strClassMap.put(oc.toString(), oc);
		}
		// Transfer an axiom string to the corresponding axiom
		HashSet<HashSet<OWLAxiom>> allMUPS = new HashSet<HashSet<OWLAxiom>>();
		for(String ucIRI : ucMUPSStr.keySet()) {
			OWLClass oc = strClassMap.get(ucIRI);
			//allMUPS.clear();
			for(HashSet<String> oneMUPSStr : ucMUPSStr.get(ucIRI)) {				
	    		HashSet<OWLAxiom> oneMUPS = new HashSet<OWLAxiom>();
	    		for(String ax : oneMUPSStr) {
	    			OWLAxiom a = strAxiomMap.get(ax);	    			
	    			if(a == null) {
	    				for(String ax2 : oneMUPSStr) {
	    					System.out.println("  str:  "+ax2);
	    				}
	    				
	    				System.out.println("null \n");
	    				continue;
	    			}
	    			oneMUPS.add(a);
	    		}
	    		allMUPS.add(new HashSet<OWLAxiom>(oneMUPS));
	    	}
			//ucMUPS.put(oc, new HashSet<HashSet<OWLAxiom>>(allMUPS));			
		}
		//HashSet<HashSet<OWLAxiom>> mips = ComputeMIPS.computeMIPS(ucMUPS);
		
		return allMUPS;
	}

	

	
	public static void mergeOnto(String stableOntName, String unstableOntName, String resPath) {
		String sourceOntoPath = "data/incOnt/" + stableOntName + ".owl";
		String targetOntoPath = "data/incOnt/" + unstableOntName + ".owl";
		OWLOntology stableOnt = OWLTools.openOntology("file:" + sourceOntoPath);
		OWLOntology unstableOnt = OWLTools.openOntology("file:" + targetOntoPath);
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>(stableOnt.getLogicalAxioms());
		allAxioms.addAll(unstableOnt.getLogicalAxioms());
		try {
			OWLTools.saveOntology(allAxioms, resPath);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
	public static void printAxiomScore(HashMap<OWLAxiom, Double> axiomRankMap) {		
		for(OWLAxiom axiom : axiomRankMap.keySet()) {
			double rank = axiomRankMap.get(axiom);		
			System.out.println("** axiom: "+ axiom.toString()+"  , rank = "+rank);
		}		
	}
	
	public static HashSet<OWLAxiom> getOWLAxioms(HashSet<OWLAxiom> axioms, HashSet<String> axiomsStr, 
			ArrayList<String> axiomList, ArrayList<String> sentenceList) {
		HashSet<OWLAxiom> owlAxioms = new HashSet<OWLAxiom>();
		for(String axStr : axiomsStr) {
			int index = sentenceList.indexOf(axStr);
			String axStr2 = axiomList.get(index);
			for(OWLAxiom ax : axioms) {
				if(ax.toString().equalsIgnoreCase(axStr2)) {
					owlAxioms.add(ax);
					break;
				}
			}			
		}
		return owlAxioms;
	}
	
	
	public static HashMap<String, Double> computeScores(HashSet<HashSet<String>> mips, HashMap<String, float[]> s_m,
			String method, ArrayList<String> axiomList, ArrayList<String> sentenceList) {
		HashMap<String, Double> sentScores = new HashMap<String, Double>();
		// Obtain the union of all MIPS
		HashSet<String> mipsUnion = new HashSet<String>();
		for (HashSet<String> oneMIPS : mips) {
			mipsUnion.addAll(oneMIPS);
		}

		for (String sentInMIPS : mipsUnion) {
			//System.out.println(" ** Scoring axiom " + sentInMIPS);
			double score = computeScore(mips, sentInMIPS, s_m, method);	
			score = Math.round(score*100)*1.0/100;
			sentScores.put(sentInMIPS, score);
		}
		return sentScores;
	}
	

	
	public static double computeScore(HashSet<HashSet<String>> mips, String sent, HashMap<String, float[]> s_m,
			String method) {
		
		double mc = 0.0;		
		for (HashSet<String> oneMIPS : mips) {
			mc += computeCohAgg(oneMIPS, sent, s_m, method);
		}
		return mc;
	}
	
	public static double computeCohAgg(HashSet<String> oneMIPS, String sent, HashMap<String, float[]> s_m,
			String method) {		
		
		double agg = 0.0;
		float[] vector = s_m.get(sent);	
		for (String sent1 : oneMIPS) {
			if(sent1.equalsIgnoreCase(sent)) {
				agg += 1.0;
			} else {
				agg += sim(s_m.get(sent1), vector, method);
			}			
		}
		double cohAgg = agg / oneMIPS.size();
		return cohAgg;
	}
	

	public static double sim(float[] v1, float[] v2, String method) {
		double result = 0.0;
		if (method == "Cos") {
			result = cos_sim(v1, v2);
		} else if (method == "Euc") {
			result = euc_sim(v1, v2);
		}
		return result;
	}
	
	public static double cos_sim(float[] v1, float[] v2) {
		double dotProduct = dotProduct(v1, v2);
		double normV1 = norm(v1);
		double normV2 = norm(v2);
		double similarity = (1 + dotProduct / (normV1 * normV2)) / 2;
		return similarity;
	}
	
	public static float dotProduct(float[] a, float[] b) {
		float result = (float) 0.0;
		for (int i = 0; i < a.length; i++) {
			result += a[i] * b[i];
		}
		return result;
	}
	
	public static double norm(float[] v) {
		double result = 0.0;
		for (int i = 0; i < v.length; i++) {
			result += v[i] * v[i];
		}
		return Math.sqrt(result);
	}

	public static double euc_sim(float[] v1, float[] v2) {
		double result = 0.0, sum = 0.0;
		for (int i = 0; i < v1.length; i++) {
			sum += (v1[i] - v2[i]) * (v1[i] - v2[i]);
		}
		result = 1.0 / (1.0 + Math.sqrt(sum));
		return result;
	}

	
	public static ArrayList<String> readFile(String filePath) throws Exception {
		ArrayList<String> sentenceList = new ArrayList<>();		
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		String line;
		while ((line = reader.readLine()) != null) {
			sentenceList.add(line);
		}
		return sentenceList;
	}
	
	public static HashSet<HashSet<String>> getAxiomSent(HashSet<HashSet<OWLAxiom>> mips, 
			ArrayList<String> axiomList, ArrayList<String> sentList) {
		HashSet<HashSet<String>> mipsSents = new HashSet<HashSet<String>>();
		for(HashSet<OWLAxiom> oneMIPS : mips) {
			HashSet<String> oneSet = new HashSet<String>();
			for(OWLAxiom ax : oneMIPS) {
				String axStr = ax.toString();
				int index  = axiomList.indexOf(axStr);
				String sent = sentList.get(index);
				oneSet.add(sent);
			}
			mipsSents.add(oneSet);
		}
		return mipsSents;
	}
	
	public static HashMap<String, float[]> getSentEmb(ArrayList<String> sentenceList, String result_file_name) {
		HashMap<String, float[]> s_m = new HashMap<>();
			
		try {			
			BufferedReader reuslt_reader = new BufferedReader(new FileReader(result_file_name));
			String line;
			int i = 0;
			while ((line = reuslt_reader.readLine()) != null) {
				float[] vetor = new float[770];
				int index_vector = 0;
				String[] values = line.split(" ");				
				for(String value : values) {
					float dt = Float.valueOf(value);
					vetor[index_vector] = dt;
					index_vector++;
				}				
				s_m.put(sentenceList.get(i++), vetor);
			}
			
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}		
		return s_m;
	}
	
	public static double getThresholdWithMinMax(
			HashSet<HashSet<String>> sets,
			HashMap<String,Double> weights) {
		
		// MimMax function
		double max = 0;
		for (HashSet<String> axiomSet : sets) {
			double min = 1;
			for (String axiom : axiomSet) {
				double weight = weights.get(axiom);
				if (min > weight) {
					min = weight;
				}
			}
			if (min > max) {
				max = min;
			}
		}
		return max;
	}
	
	/**
	 * Randomly generate the given number of weights
	 * 
	 * @param size_Ax
	 * @return
	 */
	public static ArrayList<Double> generateRandomWeights(int size_Ax) {
		ArrayList<Double> weights = new ArrayList<Double>();
		double value;
		for (int i = 0; i < size_Ax;) {
			value = Math.random() - 0.01;
			if (value > 0.0 & value < 1) {
				weights.add(value);
				i++;
			}
		}
		return weights;
	}
	

	public static boolean Checking(HashSet<String> Remov_Axiom, HashSet<HashSet<String>> Union_Mups) {
		boolean check = true;
		for (HashSet<String> confl : Union_Mups) {
			if (check == true) {
				check = false;
				for (String axiom : Remov_Axiom) {
					if (confl.contains(axiom)) {
						check = true;
					}
				}
			}
		}

		return check;
	}
	
	public static ArrayList<String> getAxiomList(HashSet<HashSet<String>> Union_Mups) {
		ArrayList<String> Set_Axiom = new ArrayList<String>();
		HashSet<String> axioms = new HashSet<String>();
		for (HashSet<String> confl : Union_Mups) {
			axioms.addAll(confl);
		}
		Set_Axiom.addAll(axioms);
		return Set_Axiom;
	}



	
	public static String change_Format_conf(String variable) {
		String variable0 = "", variable1 = "", variable2 = "";
		int indice1 = 0, indice2 = 0;

		indice1 = variable.indexOf("(") + 1;
		variable0 = (String) variable.subSequence(0, indice1);
		variable = variable.replace(variable0, "");
		variable = variable.replace(")", "");
		indice1 = variable.indexOf(" ") + 1;
		variable2 = (String) variable.subSequence(0, indice1);
		variable = variable.replace(variable2, "");
		variable2 = change_Format(variable2);
		variable1 = change_Format(variable);
		variable = variable0 + variable2 + " , " + variable1 + ")";
		return variable;
	}
	
	public static String change_Format(String variable) {
		int indice1 = 0, indice2 = 0;
		indice1 = variable.indexOf("#") + 1;
		indice2 = variable.length();
		variable = (String) variable.subSequence(indice1, indice2);
		variable = variable.replace(" ", "");
		variable = variable.replace(">", "");
		return variable;
	}
	
	public static HashSet<String> getCplexResult(IloCplex cplex, ArrayList<String> Set_Axiom)
			throws IloException {
        HashSet<String> axiomSet = new HashSet<String>();
		if (cplex.populate()) {
			IloLPMatrix lp = (IloLPMatrix) cplex.LPMatrixIterator().next();
			double[] x = cplex.getValues(lp);
			//System.out.println("cplex result: "+x);
			for (int j = 0; j < x.length; ++j) {
				if (x[j] == 1) {
					int i = 0;
					for (String axiom : Set_Axiom) {
						if (i == j) {
							axiomSet.add(axiom);
						}
						i++;
					}
				}
			}
		}
		return axiomSet;
	}
	
	public static void printAxioms(HashSet<String> axioms){
		int i = 0;
		for(String axiom : axioms){
			System.out.println("["+(i++)+"] "+axiom.toString());;
		}
		System.out.println();
	}
	
	public static void printAxioms(HashSet<String> axioms, HashMap<String,Double> weights){
		int i = 0;
		for(String axiom : axioms){
			System.out.println("["+(i++)+"] "+axiom.toString()+" : "+weights.get(axiom));;
		}
		System.out.println();
	}


}
