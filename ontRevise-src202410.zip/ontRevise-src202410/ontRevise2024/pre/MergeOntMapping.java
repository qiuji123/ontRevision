package edu.njupt.radon.exp.ontRevise2024.pre;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.parser.AlignmentParser;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class MergeOntMapping {
	
	static int incohOntNum = 0;
	static int incosOntNum = 0;
	
	public static void main(String[] args) throws Exception {
		mergeConfMappings();
	}
	
    public static void mergeHumMou() throws Exception {
		
		String o1name = "human";
		String o2name = "mouse";
		String mappingName = "ALIN-mouse-human";
		String ontoRoot = "onto/oaei2020/anatomy/";
		String onto1Path = ontoRoot+o1name+".owl";
		String onto2Path = ontoRoot+o2name+".owl";
		String mappingRoot = "onto/oaei2020/anatomy-alignments/";
		String newOntoRoot = "onto/oaei2020/mergedOnt/";
			
		// 生成时间测试
		Long tic=System.currentTimeMillis();
		mergeOntPair(ontoRoot, onto1Path, onto2Path, mappingRoot, mappingName, newOntoRoot);
		// 输出生成时间
        Long toc=System.currentTimeMillis();
		System.out.println("The consumption of time is "+(toc-tic) +" ms");
	}
	
	public static void mergeConfMappings() throws Exception {
		
		String ontoRootPath = "data/conf2021/ontofarm/";
		String mappingRootPath = "data/conf2021/results/";
		String newOntoRoot = "data/conf2021/mergedOnt/";
		
		File mappingsFile = new File(mappingRootPath);
		for (File mappingFile : mappingsFile.listFiles()) {		
			if(mappingFile.isDirectory()) {
				continue;
			}
			// 提取 本体1-本体2 部分 ， 即.rdf 前面的部分
			String fName = mappingFile.getName();
			/*if(!fName.contains("TOM-iasted-sigkdd")) {
				continue;
			}*/
			String system = fName.substring(0, fName.indexOf("-"));
			String o1Name = fName.substring(fName.indexOf("-")+1,fName.lastIndexOf("-"));
			String o2Name = fName.substring(fName.lastIndexOf("-")+1, fName.lastIndexOf("."));
			
			
			String mappingName = system+"-"+o1Name+"-"+o2Name;
			mergeOntPair(ontoRootPath, o1Name, o2Name, mappingRootPath, mappingName, newOntoRoot);				
		}
	}
	
	public static void mergeOntPair(String ontoRoot, String o1Name, String o2Name, 
			String mappingRoot, String mappingName, String newOntoPath) throws Exception {
		
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> stableAxioms = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> incoAxioms = new HashSet<OWLAxiom>();
	    HashMap<OWLAxiom,Double> weights = null;	    
	    //read two ontologies
		OWLOntology sourceOnto = OWLTools.openOntology("file:"+ontoRoot +o1Name+".owl");	
		OWLOntology targetOnto = OWLTools.openOntology("file:"+ontoRoot +o2Name+".owl");	
		stableAxioms.addAll(sourceOnto.getLogicalAxioms());
		stableAxioms.addAll(targetOnto.getLogicalAxioms());	
		//System.out.println("stable axioms: "+stableAxioms.size());
		allAxioms.addAll(stableAxioms);
		
		
		//read mapping
		AlignmentParser align = new AlignmentParser(sourceOnto, targetOnto);
		weights = align.readMappingsFromFile(mappingRoot+mappingName+".rdf");
		incoAxioms.addAll(weights.keySet());
		allAxioms.addAll(incoAxioms);
		//System.out.println("unstable axioms: "+weights.size());
		// 		
		boolean doSave = false;
		if (ReasoningTools.isConsistent(allAxioms)) { // 一致的
			int ucNumber = ReasoningTools.getUnsatiConcepts(allAxioms).size();
			if(ucNumber > 0) {
				doSave = true;
				//System.out.println("  Number of UCs: " + ucNumber);
				System.out.println("========="+mappingName);
				System.out.println(" incoherent onto "+(incohOntNum++)+" : "+stableAxioms.size()+"  & " + weights.size()+" & " + ucNumber);
			}
			
			
		} else { // 不一致的
			System.out.println("========="+mappingName);
			System.out.println("  Inconsistent onto "+(incosOntNum++));
			doSave = true;
		}
		// 保存本体
		/*if(doSave) {
			System.out.println("  o1 size : "+sourceOnto.getLogicalAxiomCount());
			System.out.println("  o2 size : "+targetOnto.getLogicalAxiomCount());
			
			String newOntPath = newOntoPath+o1Name+"-"+o2Name+".owl";
			File f = new File(newOntPath);
			if(!f.exists()) {
				OWLTools.saveOntology(stableAxioms, newOntoPath+o1Name+"-"+o2Name+".owl");
			} else {
				System.out.println("   Ontology exists: "+o1Name+"-"+o2Name);
			}
			OWLTools.saveOntology(incoAxioms, newOntoPath+mappingName+".owl");
		}*/
		
		OWLTools.manager.removeOntology(sourceOnto);
		OWLTools.manager.removeOntology(targetOnto);
	}
	
	

}
