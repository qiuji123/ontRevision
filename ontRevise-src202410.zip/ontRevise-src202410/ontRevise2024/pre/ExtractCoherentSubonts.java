package edu.njupt.radon.exp.ontRevise2024.pre;

import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class ExtractCoherentSubonts {
	
	int pruneWindow = 10;
	
    public static void main(String[] args) throws Exception {
		
    	ExtractCoherentSubonts extract = new ExtractCoherentSubonts();
    	//extract.generateSubOnts();
    	extract.checkCoherence();
	}
    
      
    public void checkCoherence() throws Exception {
    	String ontoName = "km1500-2000";
    	String newOntPath = "file:data/incOnt/"+ontoName+"-";
    	
    	for(int i=1; i<2; i++) {
    		OWLOntology onto1 = OWL.manager.loadOntology(IRI.create(newOntPath+i+".owl"));
        	OWLOntology onto2 = OWL.manager.loadOntology(IRI.create(newOntPath+(i+1)+".owl"));  
        	HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
    		allAxioms.addAll(onto1.getLogicalAxioms());
    		allAxioms.addAll(onto2.getLogicalAxioms());
    		System.out.println(ontoName+"-"+i+", "+ontoName+"-"+(i+1)+" : "+ReasoningTools.getUnsatiConcepts(allAxioms).size());
    		OWL.manager.removeOntology(onto1);
    		OWL.manager.removeOntology(onto2);
    	}
    	
		
    }
    
    public void generateSubOnts() throws Exception {
    	int subOntSize = 4000;
		int subOntNum = 3;
		String ontoName = "km1500";
		String ontoPath = "file:data/incOnt/"+ontoName+".owl";	
		String newOntPath = "data/incOnt/"+ontoName;
		
		OWLOntology onto = OWL.manager.loadOntology(IRI.create(ontoPath));
		HashSet<OWLAxiom> ontoAxioms = new HashSet<>();
		if(!ReasoningTools.isConsistent(onto, OWL.manager)) {
			ontoAxioms = OWLTools.getTBox(onto);			
		} else {
			ontoAxioms = new HashSet<>(onto.getLogicalAxioms());
		}	
		this.generateSubOnts(ontoAxioms, subOntSize, subOntNum, newOntPath);
    }
	
	public HashSet<HashSet<OWLAxiom>> generateSubOnts(HashSet<OWLAxiom> ontoAxioms,
			int subOntSize, int subOntNum, String newOntPath) throws Exception {
		
		HashSet<HashSet<OWLAxiom>> subOnts = new HashSet<HashSet<OWLAxiom>>();
		HashSet<OWLAxiom> axiomsLeft = new HashSet<OWLAxiom>(ontoAxioms);		
		HashSet<OWLAxiom> subOnt = new HashSet<OWLAxiom>();
		HashSet<OWLAxiom> winOnt = new HashSet<OWLAxiom>();
		int winCounter = 0;
		for(OWLAxiom ax : axiomsLeft) {
			winCounter++;
			if(winCounter <= this.pruneWindow) {
				winOnt.add(ax);
			} else {
				subOnt.addAll(winOnt);
				//System.out.println("   add 10 axioms to a sub-onto");
				
				if(!ReasoningTools.isCoherent(subOnt)) {
					subOnt.removeAll(winOnt);
					//System.out.println("     remove 10 axioms from a sub-onto");
					
				} else {
					if(subOnt.size()>= subOntSize) {
						subOnts.add(new HashSet<OWLAxiom>(subOnt));
						System.out.println("sub-onto : "+subOnt.size()+", coherent? "+ReasoningTools.isCoherent(subOnt));
						OWLTools.saveOntology(subOnt, newOntPath+"-"+subOntSize+"-"+subOnts.size()+".owl");
						subOnt.clear();
						if(subOnts.size()>=subOntNum) {
							break;
						}
					}
				}
				winCounter = 1;
				winOnt.clear();
				winOnt.add(ax);
			}
		}
		
		return subOnts;
	}
	
	

}
