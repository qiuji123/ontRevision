package edu.njupt.radon.exp.ontRevise2024;

import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.relative.RelativeDebug;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.FileTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class ComputeOntRelativeMUPS {

	String stableOntName;
	String unstableOntName;
	String resPath;
	OWLOntology unstableOnt;
	OWLOntology stableOnt;
	HashSet<OWLAxiom> stableAxioms;
	HashSet<OWLAxiom> unstableAxioms;
	HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
	long explainTime = 0, repairTime = 0;


	public static void main(String[] args)  throws Exception {		
		// parameters to be configured
		String stabOntName = "relOnt"; // km1500-1000-7
		String rebuttalOntName = "rebOnt";  // km1500-1000-8
		String resPath = "results/relativeMUPS/"+stabOntName+"-"+rebuttalOntName+"/";
		String ontoRoot = "data/onto-km/";
		
		FileTools.checkPath(resPath);
		
		ComputeOntRelativeMUPS revise = new ComputeOntRelativeMUPS(stabOntName, rebuttalOntName, resPath, ontoRoot);
		revise.doRevision();	
	}
	
	public ComputeOntRelativeMUPS(String stableOntName, String unstableOntName, 
			String resPath, String ontoRoot) {
		String sourceOntoPath = ontoRoot + stableOntName + ".owl";
		String targetOntoPath = ontoRoot + unstableOntName + ".owl";
		stableOnt = OWLTools.openOntology("file:" + sourceOntoPath);
		unstableOnt = OWLTools.openOntology("file:" + targetOntoPath);
		stableAxioms = new HashSet<OWLAxiom>(stableOnt.getLogicalAxioms());
		unstableAxioms = new HashSet<OWLAxiom>(unstableOnt.getLogicalAxioms());
		allAxioms.addAll(stableAxioms);
		allAxioms.addAll(unstableAxioms);
		for(OWLAxiom a : stableAxioms) {
			System.out.println(a.toString());
		}
		System.out.println("unstable: ");
		for(OWLAxiom a : unstableAxioms) {
			System.out.println(a.toString());
		}
		this.resPath = resPath;
		this.stableOntName = stableOntName;
		this.unstableOntName = unstableOntName;
	}
	
	public void doRevision() {
		    	
    	String logPath = resPath+"explanations-log.txt"; 
		System.setOut((new PrintStreamObject(logPath)).ps);	
    	
    	HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(allAxioms);
		System.out.println("ucs: "+ucs.size());
		RelativeDebug find = new RelativeDebug(allAxioms, unstableAxioms);
		//HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		int i = 0;
		long st = System.currentTimeMillis();
		for(OWLClass uc : ucs) {
			System.out.println("uc <"+(i++)+"> "+uc.toString());	
			/*if(i < 65) {
				continue;
			}
			*/
			HashSet<HashSet<OWLAxiom>> clMUPS = find.getMUPS(uc);			
			conflicts.addAll(clMUPS);	

			if(clMUPS==null || clMUPS.size()==0){
				System.out.println("  Cannot find mups for incoherence.");
				i --;
				break;
			} 
		}
		explainTime += System.currentTimeMillis() - st;
		
		System.out.println("Time to explain (ms): " + this.explainTime);			
	}
}
