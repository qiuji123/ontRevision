package edu.njupt.radon.exp.ontRevise2024;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class CollectResultsBasedLocalMips {
	
	static String groupName = "";
	
	public static void main(String[] args) throws Exception{
		readDiagResults();
	}
	
	public static void readDiagResults()  throws Exception{	
		// reviseConf2021  reviseOntMips
		groupName = "reviseOntGroup8";
		String resPath = "results/reviseOnt/"+groupName+"/";
		PrintWriter output =  new PrintWriter(new BufferedWriter(new FileWriter(resPath+"results-group.xls")),true); 
		outputHeader(output);
				
		String resFilePath = "";
		File f = new File(resPath);
		for(File ontoF : f.listFiles()) {	
			if(!ontoF.isDirectory()) {
				continue;
			}
			String ontoName = ontoF.getName();
			System.out.println("onto: "+ontoName);			
			resFilePath = resPath+ontoName+"/";	
			for(File logF : ontoF.listFiles()) {
				if(logF.isDirectory()) {
					continue;
				}
				output.print(Tools.getOntoName(ontoName));
				output.print("\t");
				
				String[] logName = logF.getName().split("-");
				System.out.println("   strategy : "+logName[0]);
				output.print(Tools.getStrategyName(logName[0]));
				output.print("\t");			
				if(groupName.trim().length()!=0) {
					String n = groupName.replace("reviseOntGroup", "");
					if(n.trim().length()==0) {
						n = "10";
					}
					output.print(n);
					output.print("\t");
			    }	
				
											
				outPutInfo(resFilePath+logF.getName(), output);
			}
		}
	}
	

	
	public static void outPutInfo(String filePath, PrintWriter output) throws Exception {
		
		BufferedReader reader = new BufferedReader(new FileReader(filePath));

		int removedAxioms = 0, rmAx0 = 0;
		long repTime = 0;   
		long checkTime = 0; 
		long expTime = 0;
		boolean diagnosisBegin = false;
		
		int expUcNum = 0;
		
		int mupsNumMax = 0;
		int mupsNumMin = 1000;
		int mupsNumTotal = 0;
		int ucMUPSNum = 0;
		boolean mupsBegin = false;		

		int mipsNum = 0;
		int mipsUnionSize = 0;
		int oneMipsSize = 0;
		int minMips = 1000;
		int maxMips = 0;
		boolean mipsBegin = false;
		boolean foundOneMIPS = false;
		
		boolean finalTimeBegin = false;
		
		String line ;
		while ((line=reader.readLine())!=null) {
			// removed axioms
			if(line.startsWith("** All removed axioms (global)") ){
				diagnosisBegin = true;
			} else if(diagnosisBegin && line.contains("> ")) {
				removedAxioms ++;
			} else if(diagnosisBegin && line.trim().length() == 0) {
				diagnosisBegin = false;	
			} else if(line.startsWith(" This concept")) {
				expUcNum --;
				
				// mups info
			} else if(line.startsWith("uc <")||line.startsWith("** Conflicts")) {
				if(line.startsWith("uc <")) {
					expUcNum++;
				}				
				if(ucMUPSNum != 0) {
					mupsNumTotal += ucMUPSNum;
					if(ucMUPSNum>mupsNumMax) {
						mupsNumMax = ucMUPSNum;
					}
					if(ucMUPSNum < mupsNumMin) {
						mupsNumMin = ucMUPSNum;
					}
					ucMUPSNum = 0;
				}	
			} else if(line.startsWith("Explanation <")) {
				mupsBegin = true;
			} else if(line.isEmpty() && mupsBegin) {
				mupsBegin = false;
				ucMUPSNum ++;
				
				// mips infor
			} else if(line.startsWith(" conf <")) {
				mipsBegin = true;
				if(oneMipsSize != 0 ) {
					foundOneMIPS = true;
				}
			} else if(line.startsWith("    ") && mipsBegin) {
				oneMipsSize ++;
			} else if(line.isEmpty() && mipsBegin) {
				mipsBegin = false;
				foundOneMIPS = true;	
				
				// time
			} else if(line.startsWith("Time to explain (ms):")) {
				String tStr = line.substring(line.indexOf(": ")+2);
				expTime += Long.valueOf(tStr);
				finalTimeBegin = true;
			} else if(line.startsWith("Time to repair (ms):") && !finalTimeBegin) {
				String tStr = line.substring(line.indexOf(": ")+2);
				repTime += Long.valueOf(tStr);
			} else if(line.startsWith("Time to check redundancy (ms):")&& !finalTimeBegin) {
				String tStr = line.substring(line.indexOf(": ")+2);
				checkTime += Long.valueOf(tStr);
			}
			
			if(foundOneMIPS) {
				mipsNum ++;
				mipsUnionSize += oneMipsSize;
				if(oneMipsSize > maxMips) {
					maxMips = oneMipsSize;
				}
				if(oneMipsSize < minMips) {
					minMips = oneMipsSize;
				}
				oneMipsSize = 0;
				foundOneMIPS = false;
			}
		}
		
		output.print(expUcNum);
		output.print("\t");
		output.print(((mupsNumTotal*1.0)/expUcNum));
		output.print("\t");
		output.print(mupsNumMax);
		output.print("\t");
		output.print(mupsNumMin);		
		output.print("\t");
		
		output.print(mipsNum);
		output.print("\t");
		//System.out.println("      average size of an explanation: "+ ((mipsUnionSize*1.0)/expNum));
		output.print(((mipsUnionSize*1.0)/mipsNum));
		output.print("\t");
		//System.out.println("      max size of an explanation: "+maxMips);
		output.print(maxMips);
		output.print("\t");
		//System.out.println("      min size of an explanation: "+minMips);
		output.print(minMips);
		output.print("\t");
		
		System.out.println("      removed axioms : "+removedAxioms);
		output.print(removedAxioms);
		output.print("\t");
		
		System.out.println("      explain time : "+expTime);
		output.print(expTime);
		output.print("\t");
		System.out.println("      repair time : "+repTime);
		output.print(repTime);
		output.print("\t");
		System.out.println("      check time : "+checkTime);
		output.print(checkTime);
		output.print("\t");
		System.out.println("      total repair time : "+(checkTime+repTime));
		output.print(checkTime+repTime);
		output.println();
		
	}
	
	
	
	public static void outputHeader(PrintWriter  output){
		output.print("Onto Pair");
	    output.print("\t");
	    output.print("Strategy");
	    output.print("\t");
	    if(groupName.trim().length()!=0) {
	    	output.print("n");		
			output.print("\t");
	    }		
		output.print("explainedUcNum");		
		output.print("\t");
		
		output.print("mups number (avg)");		
		output.print("\t");
		output.print("mups number (max)");		
		output.print("\t");
		output.print("mups number (min)");		
		output.print("\t");
		
		output.print("#AllMips");
		output.print('\t');
		output.print("MipsSize_avg");
		output.print('\t');
		output.print("MipsSize_max");
		output.print('\t');
		output.print("MipsSize_min");
		output.print('\t');
		
		output.print("#Removed Axioms");
		output.print('\t');
		
		output.print("Explain Time");
		output.print('\t');
		output.print("Repair Time");
		output.print('\t');
		output.print("Check Redundancy Time");
		output.print('\t');
		output.print("Total Repair Time(ms)");
		output.println();
	}




}
