package edu.njupt.radon.exp.ontRevise2024;

import java.io.File;
import java.util.HashSet;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import edu.njupt.radon.debug.incoherence.relative.RelativeDebug;
import edu.njupt.radon.utils.OWLTools;
import edu.njupt.radon.utils.io.PrintStreamObject;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class ComputeMappingMUPS {

	String stableOntName;
	String unstableOntName;
	String resPath, logPath;
	OWLOntology unstableOnt;
	OWLOntology stableOnt;
	HashSet<OWLAxiom> stableAxioms;
	HashSet<OWLAxiom> unstableAxioms;
	HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
	long explainTime = 0, repairTime = 0;
	
	public static void main(String[] args) throws Exception {
		
		String system = "OTMapOnto";//LogMapLt-cmt-ekaw
		String stableOntName = "cmt-conference"; // GMap: cmt-sigkdd, edas-ekaw; OTMapOnto-cmt-conference
		String unstableOntName = system+"-"+stableOntName;
		String ontoRoot = "data/onto-mapping/";
		String resPath = "results/conf2021Mups/"+unstableOntName+"/";
		String logPath = resPath+"explanations-log.txt"; 
		
		File f = new File(resPath);
		if(!f.exists()) {
			f.mkdirs();
		}
		
		ComputeMappingMUPS revise = new ComputeMappingMUPS(ontoRoot, stableOntName,
				unstableOntName, resPath, logPath);
		revise.doCompute();	
		
	}
	
	public ComputeMappingMUPS(String ontRoot, String stableOntName, String unstableOntName, 
			String resPath, String logPath) {
		
		String sourceOntoPath = ontRoot + stableOntName + ".owl";
		String targetOntoPath = ontRoot + unstableOntName + ".owl";
		stableOnt = OWLTools.openOntology("file:" + sourceOntoPath);
		unstableOnt = OWLTools.openOntology("file:" + targetOntoPath);
		stableAxioms = new HashSet<OWLAxiom>(stableOnt.getLogicalAxioms());
		unstableAxioms = new HashSet<OWLAxiom>(unstableOnt.getLogicalAxioms());
		allAxioms.addAll(stableAxioms);
		allAxioms.addAll(unstableAxioms);
		this.resPath = resPath;
		this.logPath = logPath;
		this.stableOntName = stableOntName;
		this.unstableOntName = unstableOntName;
	}
	
	
	
	public void doCompute() throws Exception {
		
		System.setOut((new PrintStreamObject(logPath)).ps);		
		System.out.println("Ontology size: "+allAxioms.size());

		HashSet<OWLClass> ucs = ReasoningTools.getUnsatiConcepts(allAxioms);
		System.out.println("ucs: "+ucs.size());
		RelativeDebug find = new RelativeDebug(allAxioms, unstableAxioms);
		//HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> mups = new HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>>();
		HashSet<HashSet<OWLAxiom>> conflicts = new HashSet<HashSet<OWLAxiom>>();
		int i = 0;
		long st = System.currentTimeMillis();
		for(OWLClass uc : ucs) {			
			System.out.println("uc <"+(i++)+"> "+uc.toString());	
			/*if(i < 44) {
				continue;
			} */
			
			HashSet<HashSet<OWLAxiom>> clMUPS = find.getMUPS(uc);			
			conflicts.addAll(clMUPS);	
			if(clMUPS==null || clMUPS.size()==0){
				System.out.println("  Cannot find mups for incoherence.");
				i --;
				break;
			} 
		}
		explainTime += System.currentTimeMillis() - st;
		System.out.println("Time to explain (ms): " + this.explainTime);	
		
	}

	
}
